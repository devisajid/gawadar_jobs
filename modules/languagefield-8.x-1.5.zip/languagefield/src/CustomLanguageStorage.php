<?php

namespace Drupal\languagefield;

use Drupal\Core\Config\Entity\ConfigEntityStorage;

/**
 * Storage for custom_language entities.
 */
class CustomLanguageStorage extends ConfigEntityStorage {

}
