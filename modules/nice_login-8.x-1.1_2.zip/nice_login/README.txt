CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Recommended modules
 * Installation
 * Configuration
 * Troubleshooting
 * FAQ
 * Maintainers

INTRODUCTION
------------

Nice login improve look of pages /user/login, user/register and user/password,
by removing standards tabs Login, Reset Password and Create an account, and
injecting inside each form the relevants links.

Nice login module provide basic css and wrapper for the
login / register/ reset password forms.
You should theme these forms according to your active theme.

For example, using a bootstrap base theme, you could add these following rules
in your styles to center the forms.

.wrapper-nice-login {
  .make-xs-column(12);
  .make-sm-column(6);
  .make-sm-column-offset(3);
}


REQUIREMENTS
------------

None


INSTALLATION
------------

 * Install as you would normally install a contributed Drupal module. See:
   https://drupal.org/documentation/install/modules-themes/modules-7
   for further information.
 * And voila


CONFIGURATION
-------------

No configuration needed

TROUBLESHOOTING
---------------


FAQ
---


MAINTAINERS
-----------

Current maintainers:
 * flocondetoile - https://drupal.org/u/flocondetoile
