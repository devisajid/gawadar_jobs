This module is used to collect year part of date only in any field. 
It provides a custom field type Year Only in the field UI.

With the help of this module one can add field where he/she wants to
get year only instead of complete date.

Installation:
----------------
Installation of Year Only module is similar to other drupal modules.
To install Year Only module please follow the below steps:

1. Download the Year Only module and extract into the /modules directory.
2. Enable the module.
3. Go to manage fields in any entity and add new field of type Year Only.
